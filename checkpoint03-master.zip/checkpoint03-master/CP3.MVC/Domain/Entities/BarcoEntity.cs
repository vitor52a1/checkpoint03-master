﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CP3.MVC.Domain.Entities
{
    [Table("tb_")]
    public class BarcoEntity
    {
    }
}
